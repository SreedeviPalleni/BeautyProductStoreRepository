package com.example.demo.error;

public class ProductNotFoundException extends Exception {
	public   ProductNotFoundException(String string) {
		super(string);
	}
}
