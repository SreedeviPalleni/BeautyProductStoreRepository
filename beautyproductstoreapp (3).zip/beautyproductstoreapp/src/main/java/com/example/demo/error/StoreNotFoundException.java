package com.example.demo.error;

public class StoreNotFoundException extends Exception{
	public   StoreNotFoundException(String string) {
		super(string);
	}

	

}
