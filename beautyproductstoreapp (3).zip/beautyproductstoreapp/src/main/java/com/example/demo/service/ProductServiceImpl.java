package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.entitiy.Product;
import com.example.demo.entitiy.Store;
import com.example.demo.error.ProductNotFoundException;
import com.example.demo.error.StoreNotFoundException;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.StoreRepository;

@Service
public class ProductServiceImpl implements ProductService,UserDetailsService{
@Autowired
ProductRepository productRepository;
@Autowired
StoreRepository storeRepository;
//@Autowired
//PasswordEncoder encoder;
@Override
public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
Product e = productRepository.findByUsername(userName);
if(e==null)
	throw new UsernameNotFoundException("User not found");
	return new CustomeUserDetails(e);
}
@Override
public List<Product> getproducts() {
		
		return productRepository.findAll() ;
	}

	@Override
	public Product saveProducts(Product product,Long storeId) throws StoreNotFoundException {
		
		//return productRepository.save(product);
		if(!storeRepository.existsById(storeId)) {
			throw new StoreNotFoundException("store not found");
		}
		else {
			Store s =storeRepository.findById(storeId).get();
			product.setStore(s);
			s.getProductlist().add(product);
			return productRepository.save(product);
			
		}
		
		
			
	}

	@Override
	public void deleteProductsById(Long productId) {
		productRepository.deleteById(productId);
		
	}

	@Override
	public Product updateProductsById(Long storeId,Product product,Long productId) throws ProductNotFoundException {
		Optional<Product> p=productRepository.findById(productId);
		if(p.isPresent()) {
			Store s=storeRepository.findById(storeId).get();
			product.setStore(s);
			Product pDB=productRepository.findById(productId).get();
		if(Objects.nonNull(product.getProductName()) && !"".equalsIgnoreCase(product.getProductName())) {
		pDB.setProductName(product.getProductName());	
		}
		if(Objects.nonNull(product.getProductPrice()) ) {
			pDB.setProductPrice(product.getProductPrice());
		}
		if(Objects.nonNull(product.getStore()) ) {
			pDB.setStore(product.getStore());
		}
		if(Objects.nonNull(product.getUsername()) && !"".equalsIgnoreCase(product.getUsername())) {
			pDB.setUsername(product.getUsername());	
			}
		if(Objects.nonNull(product.getPassword()) && !"".equalsIgnoreCase(product.getPassword())) {
			pDB.setPassword(product.getPassword());	
			}
		if(Objects.nonNull(product.getRole()) && !"".equalsIgnoreCase(product.getRole())) {
			pDB.setRole(product.getRole());	
			}
		return productRepository.save(pDB);
		}
		else throw new ProductNotFoundException("Product Id Does Not Exist");
			}

	@Override
	public Product getProductsById(Long productId) throws ProductNotFoundException {
		//return productRepository.findById(productId).get();
		Optional<Product> pid=(productRepository.findById(productId));
		if(!pid.isPresent()) {
			throw new ProductNotFoundException("Product Id does not exist");
		}
		else return pid.get();
		
	}

	@Override
	public Product getProductByPrice(String price) throws ProductNotFoundException {
		Optional<Product> pprice=Optional.ofNullable(productRepository.findByproductPrice(price));
		if(!pprice.isPresent()) {
			throw new ProductNotFoundException("Product price does not exist");
		}
		else return pprice.get();
		
		//return productRepository.findByproductPrice(price);
	}

	@Override
	public Product getProductByName(String productName) throws ProductNotFoundException {
		Optional<Product> pname=Optional.ofNullable(productRepository.findByproductName(productName));
	
		//return productRepository.findByproductName(productName); 
		if(!pname.isPresent()) {
			throw new ProductNotFoundException("Product name does not exist");
		}
		else return pname.get();
	}

	

	

	

	

}
