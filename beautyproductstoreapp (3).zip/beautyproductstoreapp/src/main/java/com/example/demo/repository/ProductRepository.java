package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entitiy.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

	List<Product> findAll();

	Product save(Product product);

	void deleteById(Long productId);

	Optional<Product> findById(Long productId);

	 

	Product findByproductName(String productname);

	Product findByproductPrice(String price);

	
	Product findByUsername(String userName);

	

}
