package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entitiy.Store;
import com.example.demo.error.StoreNotFoundException;
import com.example.demo.repository.StoreRepository;
@Service
public class StoreServiceImpl implements StoreService {
@Autowired
StoreRepository storeRepository;

@Override
public List<Store> getStores() throws StoreNotFoundException {
	
	return storeRepository.findAll();
//Optional<List<Store>> sl=Optional.ofNullable((storeRepository.findAll()));
	
	//return storeRepository.save(store);
}	

@Override
public Store saveStores(Store store) throws StoreNotFoundException {
	Optional<Store> ss=Optional.ofNullable(storeRepository.save(store));
	
	return storeRepository.save(store);
	
}

@Override
public void deleteStoresById(Long storeId) {
	storeRepository.deleteById(storeId);
	
}

@Override
public Store updateStoresById(Long storeId, Store store) throws StoreNotFoundException {
	Optional<Store> s=storeRepository.findById(storeId);
	Store sDB=storeRepository.findById(storeId).get();
	if(Objects.nonNull(store.getStoreName()) && !"".equalsIgnoreCase(store.getStoreName())) {
	sDB.setStoreName(store.getStoreName());	
	}
	if(Objects.nonNull(store.getAddress()) && !"".equalsIgnoreCase(store.getAddress())) {
		sDB.setAddress(store.getAddress());
	}
	if(s.isPresent()) {
		return s.get();
	}
	else 
		throw new StoreNotFoundException("Updation is not Posiible, Entered valued already available in store");

		
	//return storeRepository.save(sDB);
}

@Override
public Store getStoresById(Long storeId) throws StoreNotFoundException {
	//return storeRepository.findById(storeId).get();
	Optional<Store> sid=storeRepository.findById(storeId);
	if(!sid.isPresent()) {
		throw new StoreNotFoundException("Store id does not exist");
	}
	else return sid.get();
}

@Override
public Store getStoresByAddress(String address) throws StoreNotFoundException {
	//return storeRepository.findByaddress(address);
	Optional<Store> sadd=Optional.ofNullable((storeRepository.findByAddress(address)));
	if(!sadd.isPresent()) {
		throw new StoreNotFoundException("Store Address does not exist");
	}
		else return sadd.get();
	
}

@Override
public Store getStoresByName(String storeName) throws StoreNotFoundException {
	Optional<Store> sname=Optional.ofNullable(storeRepository.findBystoreName(storeName));
	if(!sname.isPresent()) {
		throw new StoreNotFoundException("Store name does not exist");
	}
	else return sname.get();
}

	

}
