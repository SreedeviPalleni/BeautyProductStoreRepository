package com.example.demo.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.example.demo.entitiy.Product;
import com.example.demo.entitiy.Store;
import com.example.demo.error.ProductNotFoundException;
import com.example.demo.error.StoreNotFoundException;

public interface ProductService {

	List<Product> getproducts();

	Product saveProducts(Product product, Long storeId) throws StoreNotFoundException;

	void deleteProductsById(Long productId);

	Product updateProductsById (Long storeId ,Product product,Long productId) throws  ProductNotFoundException;

	Product getProductsById(Long productId) throws ProductNotFoundException;

	

	Product getProductByName(String productName) throws ProductNotFoundException;

	Product getProductByPrice(String price) throws ProductNotFoundException;

	//UserDetails loadUserByUsername(String username) throws UsernameNotFoundException;

	

	

}
